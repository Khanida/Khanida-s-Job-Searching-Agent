import re
import json
from typing import Any, Dict


SKILL_PATTERNS = {
    "Python": (r"\bpython\b",),
    "C++": (r"(?<!\w)c\+\+(?!\w)",),
    "Java": (r"\bjava\b",),
    "JavaScript": (r"\bjavascript\b", r"\bjs\b"),
    "TypeScript": (r"\btypescript\b",),
    "C#": (r"(?<!\w)c#(?!\w)", r"\bc-sharp\b"),
    "C": (r"\bc\s+(?:programming|language)\b", r"\bc\s*/\s*c\+\+"),
    "SQL": (r"\bsql\b",),
    "HTML": (r"\bhtml\b",),
    "CSS": (r"\bcss\b",),
    "React": (r"\breact(?:\.js)?\b",),
    "Flutter": (r"\bflutter\b",),
    "Dart": (r"\bdart\b",),
    "Android": (r"\bandroid\b",),
    "Kotlin": (r"\bkotlin\b",),
    "Swift": (r"\bswift\b",),
    "Firebase": (r"\bfirebase\b",),
    "Embedded Systems": (r"\bembedded systems?\b", r"\bmicrocontrollers?\b", r"\bfirmware\b"),
    "QA / Testing": (r"\bqa\b", r"\bquality assurance\b", r"\btest(?:ing| automation)?\b"),
    "Selenium": (r"\bselenium\b",),
    "Playwright": (r"\bplaywright\b",),
    "Linux": (r"\blinux\b",),
    "Networking": (r"\bnetwork(?:ing|s)?\b",),
    "IT Support": (r"\bit support\b", r"\bhelp ?desk\b", r"\btechnical support\b"),
    "Docker": (r"\bdocker\b",),
    "Kubernetes": (r"\bkubernetes\b", r"\bk8s\b"),
    "AWS": (r"\baws\b", r"\bamazon web services\b"),
    "Azure": (r"\bazure\b",),
    "Machine Learning": (r"\bmachine learning\b", r"\bml\b"),
    "Data Analysis": (r"\bdata analy(?:sis|tics)\b", r"\bpandas\b", r"\btableau\b", r"\bpower bi\b"),
    "Excel": (r"\bexcel\b", r"\bspreadsheets?\b"),
    "Windows": (r"\bwindows\b",),
    "CRM": (r"\bcrm\b",),
    "CAD": (r"\bcad\b",),
    "Cybersecurity": (r"\bcyber ?security\b", r"\bsiem\b", r"\bpenetration testing\b"),
    "Project Management": (r"\bproject management\b", r"\bagile\b", r"\bscrum\b"),
    "UI / UX Design": (r"\bui/?ux\b", r"\buser experience\b", r"\bfigma\b"),
    "Graphic Design": (r"\bgraphic design\b", r"\badobe (?:photoshop|illustrator)\b"),
    "Social Media Design": (r"\bsocial media design(?:s)?\b",),
    "Digital Marketing": (r"\bdigital marketing\b", r"\bseo\b", r"\bgoogle ads\b"),
    "Accounting": (r"\baccount(?:ing|antancy)\b", r"\bbookkeeping\b", r"\bquickbooks\b"),
    "Human Resources": (r"\bhuman resources\b", r"\brecruit(?:ing|ment)\b", r"\bpayroll\b"),
    "Sales": (r"\bsales\b", r"\bcustomer acquisition\b", r"\bcrm\b"),
    "Supply Chain": (r"\bsupply chain\b", r"\blogistics\b", r"\binventory management\b"),
    "Civil Engineering": (r"\bcivil engineering\b", r"\bstructural engineering\b", r"\bautocad\b"),
    "Mechanical Engineering": (r"\bmechanical engineering\b", r"\bsolidworks\b", r"\bcad\b"),
    "Electrical Engineering": (r"\belectrical engineering\b", r"\bplc\b", r"\bcircuit design\b"),
}

ROLE_EVIDENCE = {
    "Software Engineer": (
        "Python", "C++", "Java", "JavaScript", "TypeScript", "C#", "SQL", "React"
    ),
    "Frontend Developer": ("JavaScript", "TypeScript", "HTML", "CSS", "React"),
    "Mobile App Developer": ("Flutter", "Dart", "Android", "Kotlin", "Swift", "Firebase"),
    "QA Automation Engineer": ("QA / Testing", "Selenium", "Playwright", "Python", "Java"),
    "Embedded Systems Engineer": ("Embedded Systems", "C++", "C", "Python", "Electrical Engineering"),
    "IT Support Engineer": ("IT Support", "Networking", "Linux", "Windows"),
    "DevOps / Cloud Engineer": ("Docker", "Kubernetes", "AWS", "Azure", "Linux"),
    "Data Analyst": ("Data Analysis", "SQL", "Excel", "Python", "Machine Learning"),
    "Cybersecurity Analyst": ("Cybersecurity", "Linux", "Networking", "Python"),
    "Project Coordinator": ("Project Management", "Excel"),
    "UI/UX Designer": ("UI / UX Design", "Graphic Design"),
    "Graphic Designer": ("Graphic Design", "Social Media Design"),
    "Social Media Designer": ("Social Media Design", "Graphic Design"),
    "Digital Marketing Specialist": ("Digital Marketing", "Data Analysis", "Excel"),
    "Accountant": ("Accounting", "Excel"),
    "Human Resources Coordinator": ("Human Resources", "Excel"),
    "Sales Representative": ("Sales", "CRM"),
    "Operations Analyst": ("Supply Chain", "Project Management", "Excel", "Data Analysis"),
    "Civil Engineer": ("Civil Engineering", "Project Management"),
    "Mechanical Engineer": ("Mechanical Engineering", "Project Management"),
    "Electrical Engineer": ("Electrical Engineering",),
}

ROLE_CORE_SKILLS = {
    "Embedded Systems Engineer": {"Embedded Systems"},
    "QA Automation Engineer": {"QA / Testing", "Selenium", "Playwright"},
    "IT Support Engineer": {"IT Support"},
    "DevOps / Cloud Engineer": {"Docker", "Kubernetes", "AWS", "Azure"},
    "Data Analyst": {"Data Analysis"},
    "Cybersecurity Analyst": {"Cybersecurity"},
    "Project Coordinator": {"Project Management"},
    "UI/UX Designer": {"UI / UX Design"},
    "Graphic Designer": {"Graphic Design"},
    "Social Media Designer": {"Social Media Design"},
    "Digital Marketing Specialist": {"Digital Marketing"},
    "Accountant": {"Accounting"},
    "Human Resources Coordinator": {"Human Resources"},
    "Sales Representative": {"Sales"},
    "Civil Engineer": {"Civil Engineering"},
    "Mechanical Engineer": {"Mechanical Engineering"},
    "Electrical Engineer": {"Electrical Engineering"},
}

def analyze_cv(cv_text: str) -> Dict[str, Any]:
    """Derive explainable skill and role recommendations from CV text without external services."""
    text = re.sub(r"\s+", " ", cv_text or "").strip()
    lowered = text.lower()
    skills = [
        skill for skill, patterns in SKILL_PATTERNS.items()
        if any(re.search(pattern, lowered) for pattern in patterns)
    ]

    scored_roles = []
    for role, evidence in ROLE_EVIDENCE.items():
        matched = [skill for skill in evidence if skill in skills]
        core_skills = ROLE_CORE_SKILLS.get(role)
        if matched and (
            bool(core_skills.intersection(matched))
            if core_skills
            else len(matched) >= 2
        ):
            scored_roles.append((role, len(matched), matched))
    scored_roles.sort(key=lambda result: (-result[1], result[0]))

    senior_title = bool(re.search(
        r"(?im)^\s*(?:senior|lead|principal|staff)\s+[\w/& -]{0,70}"
        r"\b(?:engineer|developer|designer|manager|analyst|architect)\b",
        text,
    ))
    seniority = "unspecified"
    years = [
        int(match.group(1))
        for match in re.finditer(r"\b(\d{1,2})\+?\s+years?\b", lowered)
    ]
    if senior_title:
        seniority = "experienced"
    elif any(term in lowered for term in ("graduate", "entry-level", "entry level", "junior", "intern", "student", "fresh graduate")) or any(year <= 2 for year in years):
        seniority = "early-career"
    elif any(year >= 5 for year in years):
        seniority = "experienced"

    roles = []
    for role, _, _ in scored_roles[:5]:
        if seniority == "early-career" and role not in ("Accountant", "Sales Representative"):
            role = f"Junior {role}"
        roles.append(role)

    if skills and roles:
        summary = f"Found {len(skills)} skills and matched them to {len(roles)} potential role paths."
    elif skills:
        summary = f"Found {len(skills)} skills, but there is not enough role-specific evidence to recommend target roles yet."
    elif text:
        summary = "CV text was analyzed, but no supported skills or role signals were detected. Add clearer skills or experience details."
    else:
        summary = "Add or upload CV text to analyze skills and suggest target roles."

    return {
        "skills": skills,
        "roles": roles,
        "seniority": seniority,
        "summary": summary,
    }


def get_cv_analysis(profile: Dict[str, Any]) -> Dict[str, Any]:
    """Read persisted analysis, or derive it for older profiles without saved analysis."""
    raw_analysis = profile.get("cv_analysis")
    if isinstance(raw_analysis, dict):
        return raw_analysis
    if isinstance(raw_analysis, str) and raw_analysis:
        try:
            parsed = json.loads(raw_analysis)
            if isinstance(parsed, dict):
                return parsed
        except json.JSONDecodeError:
            pass
    return analyze_cv(profile.get("cv_text") or "")


def score_cv_match(job: Dict[str, Any], profile: Dict[str, Any]) -> Dict[str, Any]:
    analysis = get_cv_analysis(profile)
    text = f"{job.get('title', '')} {job.get('description', '')}".lower()
    candidate_skills = list(dict.fromkeys(
        list(analysis.get("skills", []))
        + [skill.strip() for skill in (profile.get("skills") or "").split(",") if skill.strip()]
    ))
    matched_skills = [
        skill for skill in candidate_skills
        if re.search(r"(?<!\w)" + re.escape(skill.lower()) + r"(?!\w)", text)
    ]

    job_title = re.sub(r"[^a-z0-9+#]+", " ", (job.get("title") or "").lower()).strip()
    target_roles = list(dict.fromkeys(
        list(analysis.get("roles", []))
        + [role.strip() for role in (profile.get("target_roles") or "").split(",") if role.strip()]
    ))
    role_matches = [
        role for role in target_roles
        if any(
            token in job_title
            for token in re.sub(r"[^a-z0-9+#]+", " ", role.lower()).split()
            if token not in {"junior", "senior", "graduate", "engineer", "developer", "specialist", "analyst"}
        )
    ]
    if any(role.lower() in job_title for role in target_roles):
        role_matches = list(target_roles)

    score = 30 + min(len(matched_skills) * 12, 48) + (22 if role_matches else 0)
    return {
        "score": min(score, 100),
        "matched_skills": matched_skills[:6],
        "matched_roles": role_matches[:3],
        "recommended_roles": analysis.get("roles", []),
    }


def assess_candidate_constraints(job: Dict[str, Any], profile: Dict[str, Any]) -> Dict[str, Any]:
    """Apply explicit candidate seniority and role/skill exclusions before Jury selection."""
    title = (job.get("title") or "").lower()
    description = (job.get("description") or "").lower()
    reasons = []

    experience_level = (profile.get("experience_level") or "entry-level").strip().lower()
    if experience_level == "entry-level":
        if re.search(
            r"\b(?:senior|sr\.?|lead|principal|staff|head of|tier\s*(?:iii|3)|level\s*3|l3)\b",
            title,
        ):
            reasons.append("The title is senior, lead, or advanced-tier, outside the candidate's entry-level preference.")
        years_required = re.search(
            r"\b(?:at least|minimum of|required|requires?|requiring)\s+"
            r"(\d{1,2})\+?\s+years?\s+(?:of\s+)?(?:professional\s+|relevant\s+|industry\s+)?experience\b",
            description,
        )
        if years_required and int(years_required.group(1)) > 2:
            reasons.append(
                f"The posting requires {years_required.group(1)}+ years of experience, above the entry-level limit."
            )
        if re.search(
            r"\b(?:experienced|seasoned)\s+(?:(?:software|backend|back-end|full[- ]stack)\s+)?"
            r"(?:engineers?|developers?|programmers?)\b",
            description,
        ):
            reasons.append("The description asks for experienced engineers or developers rather than entry-level candidates.")

    excluded_skills = [
        skill.strip()
        for skill in (profile.get("excluded_skills") or "Rust").split(",")
        if skill.strip()
    ]
    for skill in excluded_skills:
        if re.search(r"(?<!\w)" + re.escape(skill.lower()) + r"(?!\w)", f"{title} {description}"):
            reasons.append(f"The role asks for {skill}, which the candidate has explicitly said they do not know.")

    excluded_job_terms = [
        term.strip()
        for term in (profile.get("excluded_job_terms") or "backend, back-end, full-stack, full stack").split(",")
        if term.strip()
    ]
    role_text = f"{title} {description}"
    for term in excluded_job_terms:
        term_pattern = re.escape(term.lower()).replace(r"\ ", r"[\s-]*")
        if re.search(r"(?<!\w)" + term_pattern + r"(?!\w)", title):
            reasons.append(f"The job title indicates {term}, outside the candidate's preferred experience.")
        elif re.search(
            r"(?<!\w)" + term_pattern
            + r"\s+(?:development|engineering|engineer|developer|services|systems|apis)(?!\w)",
            role_text,
        ):
            reasons.append(f"The description identifies the role as focused on {term}.")

    citizenship = (profile.get("citizenship") or "").lower()
    if "saudi" not in citizenship:
        nationality_restrictions = (
            r"\bsaudi nationals? only\b",
            r"\bonly saudi nationals?\b",
            r"\bsaudi citizens? only\b",
            r"\bonly saudi citizens?\b",
            r"\bmust be (?:a )?saudi (?:national|citizen)\b",
            r"\bsaudi nationality required\b",
            r"\breserved for saudi (?:nationals?|citizens?)\b",
        )
        if any(
            re.search(pattern, f"{title} {description}")
            for pattern in nationality_restrictions
        ):
            reasons.append(
                "The posting is restricted to Saudi nationals or citizens, while the candidate profile lists a different citizenship."
            )

    residence = (profile.get("residence") or "").strip()
    preferred_city = residence.split(",", 1)[0].strip()
    job_location = (job.get("location") or "").strip()
    matches_preferred_city = bool(
        preferred_city
        and job_location
        and re.search(
            r"(?<!\w)" + re.escape(preferred_city) + r"(?!\w)",
            job_location,
            flags=re.IGNORECASE,
        )
    )

    local_expat_status = "not_applicable"
    local_expat_evidence = ""
    if (
        matches_preferred_city
        and "saudi" in residence.lower()
        and "saudi" not in citizenship
    ):
        eligibility_text = f"{title} {description}"
        restriction_patterns = (
            r"\bsaudi nationals? only\b",
            r"\bonly saudi nationals?\b",
            r"\bsaudi citizens? only\b",
            r"\bonly saudi citizens?\b",
            r"\bmust be (?:a )?saudi (?:national|citizen)\b",
            r"\bsaudi nationality required\b",
            r"\breserved for saudi (?:nationals?|citizens?)\b",
            r"\bnon[- ]saudis? (?:are )?not (?:eligible|accepted|considered)\b",
            r"\b(?:expats?|expatriates?|foreign nationals?) (?:are )?not (?:eligible|accepted|considered)\b",
            r"\b(?:no|without) (?:work )?visa sponsorship\b",
            r"\bvisa sponsorship (?:is )?(?:not available|not provided|unavailable)\b",
            r"\btransferable iqama (?:is )?not accepted\b",
        )
        positive_eligibility_patterns = (
            r"\bpakistani (?:nationals?|applicants?|candidates?) (?:are )?(?:welcome|eligible|accepted)\b",
            r"\b(?:welcome|open) to pakistani (?:nationals?|applicants?|candidates?)\b",
            r"\b(?:expats?|expatriates?) (?:are )?(?:welcome|eligible|accepted)\b",
            r"\b(?:welcome|open) to (?:expats?|expatriates?)\b",
            r"\bnon[- ]saudi (?:nationals?|applicants?|candidates?) (?:are )?(?:welcome|eligible|accepted)\b",
            r"\bforeign nationals? (?:are )?(?:welcome|eligible|accepted)\b",
            r"\ball nationalities (?:are )?(?:welcome|eligible|accepted)\b",
        )
        if any(re.search(pattern, eligibility_text) for pattern in restriction_patterns):
            local_expat_status = "restricted"
            local_expat_evidence = (
                "The local posting states that eligibility is restricted to Saudi nationals or excludes non-Saudis."
            )
            reasons.append(local_expat_evidence)
        else:
            matched_evidence = next(
                (
                    match.group(0)
                    for pattern in positive_eligibility_patterns
                    if (match := re.search(pattern, eligibility_text))
                ),
                None,
            )
            if matched_evidence:
                local_expat_status = "evidence_found"
                local_expat_evidence = (
                    f"The posting says “{matched_evidence},” supporting eligibility for Pakistani applicants. "
                    "This does not independently confirm the employer's past hiring history."
                )
            else:
                local_expat_status = "unverified"
                general_signal_patterns = (
                    r"\btransferable iqama\b",
                    r"\biqama transfer\b",
                    r"\bvisa sponsorship\b",
                    r"\bwork visa (?:sponsorship|provided|available)\b",
                    r"\bsponsorship available\b",
                )
                general_signal = next(
                    (
                        match.group(0)
                        for pattern in general_signal_patterns
                        if (match := re.search(pattern, eligibility_text))
                    ),
                    None,
                )
                if general_signal:
                    local_expat_status = "general_signal"
                    local_expat_evidence = (
                        f"The posting mentions “{general_signal},” but does not state that Pakistani applicants are eligible. "
                        "Confirm directly with the employer before treating it as suitable."
                    )
                else:
                    local_expat_evidence = (
                        f"This posting is in {preferred_city}, but it does not say whether Pakistani or other non-Saudi "
                        "applicants are eligible. Confirm directly with the employer before treating it as suitable."
                    )
            if local_expat_status in ("unverified", "general_signal"):
                reasons.append(local_expat_evidence)

    return {
        "eligible": not reasons,
        "reasons": list(dict.fromkeys(reasons)),
        "preferred_city": preferred_city,
        "matches_preferred_city": matches_preferred_city,
        "local_expat_status": local_expat_status,
        "local_expat_evidence": local_expat_evidence,
    }
